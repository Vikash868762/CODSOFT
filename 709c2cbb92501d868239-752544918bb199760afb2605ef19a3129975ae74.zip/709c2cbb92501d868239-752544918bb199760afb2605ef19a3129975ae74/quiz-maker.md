#Quiz Maker

Create a web application that allows a teacher to create a quiz. The quiz can then be taken by students. There are 3 types of users: admin, teacher, student. Of the 3 types, only the student doesn't have an account. The ID number is used to determine the student.

The admin is responsible for:

- Creating account for teacher
- Adding students

The teacher is responsible for:

- Creating Classes
- Adding Students to the Class
- Creating Quizzes
- Scheduling Quizzes
- Viewing Student Scores
- Exporting quiz results to spreadsheet

The student is responsible for:

- Taking a quiz

##Admin

The admin should have a built-in account in the database (directly add the account details in phpmyadmin or use a database seeder) the admin can then login using that account. 

The admin can also create an account for a teacher. 

Lastly, the admin can create students. He should be able to add the following data for the students: ID number, photo (you need to implement file upload and save the photo in the filesystem and then save the file path in the database), first name, last name, gender, course, year level. 

##Teacher

First the teacher goes to the admin and asks the admin to create a teacher account. 
The admin then enters the name, email and a temporary password for the teacher
once the account is created the account, the teacher can now login.

The first thing that the teacher needs to do is to create a class. The class should have a name and a description. 

Once the teacher has created the class, students can now be added to the class. The teacher can search the students by name, course and year level. When the search button is clicked, all the students that have been returned in the result can be added to the class. But the teacher should also be able to exclude specific students by clicking on a 'remove' button which removes the student from the list of results. Or click an 'add' button to add only specific students from the results. When the 'add to class' button is clicked, the app should add all the students that are currently shown in the results. If at least one student has been marked to be added, it adds that student instead.

Next the teacher can create a quiz. A quiz has a title, a detail (any instruction that the teacher wants to tell to the students who will take the quiz), time limit (number of seconds before the quiz is submitted automatically), and quiz items. Quiz items has a question, answers, and choices (for multiple choice questions). Any number of quiz items can be added to a single quiz. For multiple choice questions, 4 choices should be added. Once all the quiz items has been added, the teacher can click on the _save quiz_ button to save the quiz in the database. Once a quiz is saved, the teacher can access a quizzes page. This will list out all the quizzes that the teacher has created so far. It shows details such as the title of the quiz, the date and time when it was created, and a link to update the quiz. The title, details and the quiz items that were previously added can be updated.

Next the teacher can schedule any of the quizzes that has been created. This is where the quiz and the class can be selected from a drop-down box. And the starting date & time and ending date & time can be added. Scheduling a quiz generates a random quiz code which can then be sent by the teacher to the students so that they can take the quiz. But the students can only do so when the current date and time is already in between that of the range set by the teacher. For example, the teacher set the starting date & time of the quiz to _Nov 5, 2015 9:45 am_ and the ending date & time to _Nov 5, 2015 10:45 am_, the students should only be able to take the quiz between those times. So the student shouldn't be able to take the quiz at 10:46 am on Nov 5. 
Once a quiz has been scheduled, the teacher can access the _scheduled quizzes_ page. This will list out all the quizzes that are currently scheduled.  This is where the teacher can see the title of the quiz, the class who will take it, the quiz code, the starting and  ending date & time, and a link for updating the scheduled quiz. When this link is clicked, it would lead to the page where the teacher can update the starting and ending date & time of the quiz. Once the ending date & time passes by, the quiz should no longer be listed in this page. Instead, it should be listed in the finished quizzes page. This page shows the title of the quiz, the class who took it, the starting and ending date & time and a link that would lead to the scores page. The scores page is where the teacher can view a list of all the students in the class that was set to take that quiz. The page should show the name of the class, the total points in that quiz, the start and ending date & time, and the table which shows the ID number, name and the score of each student in that class. Additionally, the teacher should also be able to export the table in a spreadsheet.


##Student

The student is the one who will take the quiz. All they have to do is to access the _start quiz_ page and enter their ID number and quiz code. When they click on the _start quiz_ button, the page will be redirected to the quiz page. The quiz page lists out all the quiz items that were added by the teacher. The quiz items should be ordered randomly to prevent students from copying the work of their peers. If the quiz item type is an identification, a text field should be provided. If its a multiple choice type then radio buttons are provided. There should also be a count-down timer which uses the time limit added by the teacher when the quiz was created. When the count-down timer reaches 0, the quiz is automatically submitted. Moreover, if the student attempts to do any other activity on the computer when the quiz has already begun, the quiz is also immediately submitted. When JavaScript is disabled in the browser, the student shouldn't be able to take the quiz. When the quiz is submitted, the app should automatically compute the score based on the answers provided by the student. Once that's done, the page is redirected to the _quiz done_ page. This is where the score would be shown along with the total number of items in the quiz.


##Rules & Guidelines
* Use git to track the changes made to your project. Every member should have their own [Github account](https://github.com/) and the username should be set to their first name and last name (e.g. YohAsakura).
* Use Github to upload your project. Progress will be checked every week, so there should be a commit uploaded on Github at least once a week.
* You can use any front-end framework ([bootstrap](http://getbootstrap.com/), [foundation](http://foundation.zurb.com/)) to ease the work you need to do with styling the project.
* Use the [Laravel](http://laravel.com/) framework to implement the project. 
* You can use any [JavaScript](https://cdnjs.com/) or [PHP library](https://packagist.org/) that can help you to easily implement specific features such as file upload.
* For each member of the group, provide a list of things done in the project.
* Project documentation:
    * Brief summary of what the project does
    * Features
    * Database (brief description of the tables and columns used and how are they connected to each other)
    * Libraries used
    * How to use the system
* The project will be presented by each group.